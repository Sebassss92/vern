function setup() {
  createCanvas(1200, 750);
  let i;
  }

function draw() {
  background(255);
  var s = 25;
  var x = mouseX;
  var l = 20;
  let y = mouseY
  rect(50,220,550,100)
   for(i=0;i<l;i++){
     line(s*i+x,y,s*i+x,y+100)
     textSize(16);
     text(`${i}`, s*i+x-4, y+120);
   }
     


text("txtxt",100,200); 

}