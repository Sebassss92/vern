function preload(){
  rp = loadImage('rp.jpg')  
  rn = loadImage('rn.jpg')  
}
function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(251, 247, 255);
  let i = 100
  let l1,l2 
  let rg1 = new rg(i, 100, 5, 25, 100,0)
  let rg2 = new rg(i, 200, 5, 25, 100,110)
  l1 = image(rp,100,100,100,100)
  l2 = image(rn,100,200,50,100)
  rg1.show()

  rg2.show()
}
class rg {
  constructor(x, y, n, s, l,yt) {
    this.x = x
    this.y = y
    this.n = n
    this.s = s
    this.l = l
    this.yt = yt
  }
  show() {

    let dels = 0
    for (let i = 0; i != this.n; i++) {
      line(this.x + dels, this.y, this.x + dels, this.y + this.l)
      fill(0)
      textSize(16);
      text(`${i}`, this.x + dels, this.y+this.yt)
      noFill()
      
      dels += this.s

    }
  }


}