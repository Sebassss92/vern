function preload(){
  rp = loadImage('rp.jpg')  
  rn = loadImage('rn.jpg')  
}
function setup() {
  createCanvas(20000, 1000);
 
}
 let q ,w,e,r=0
function draw() {
  background(255, 222, 180);
  
  
  let mp = 0.405511811 ;
  let u = 1/16;
  let n = 20;
  let k = 1;
  let ap;
  let cero;
  let nonio;
  let lf;
  let s;
  let rg;
  
  ap = u / n;
  cero = parseInt(mp / u) * u;
  nonio = parseInt((mp - cero) / ap);
  lf = cero + nonio * ap;
  s = ((n * k - 1) * u) / n;
  rg = lf + nonio * s;


  
  let mp1 = 10.30 ;
  let u1 = 1;
  let n1 = 10;
  let k1 = 2;
  let ap1;
  let cero1;
  let nonio1;
  let lf1;
  let s1;
  let rg1;
  ap1 = u1 / n1;
  cero1 = parseInt(mp1 / u1) * u1;
  nonio1 = parseInt((mp1 - cero1) / ap1);
  lf1 = cero1 + nonio1 * ap1;
  s1 = ((n1 * k1 - 1) * u1) / n1;
  rg1 = lf1 + nonio1 * s1;
  
   
  let inin
  let inmm
  let iin
  let imm
  let es = 1500
  let es1 = es/25.4
  let lin = parseInt(mp / u) + parseInt((s * n) / u) + 1
  let lin1 = parseInt(mp1 / u1) + parseInt((s1 * n1) / u1) + 1
  let y = 50
  let y1 = 200
  let x = lf * -es
  let x1 = lf1 * -es1
   let desfase = Math.abs(lf - lf1/25.4)*es
  let d = (0.3)*es
  let d1 = (0.3)*es
   u = u * es
  s = s * es
   u1 = u1 * es1
  s1 = s1 * es1
 print(lf)
  print(lf1)
  a = image(rp,q,w,e,r)
  //nonio in
   
  for (inin = n; inin != -1; inin--) {
    line(s * inin - x + d, y+20, s * inin - x + d, y + 100)
    textSize(16);
    text(`${inin}`, s * inin - x - 6 + d, y +10);
  }
  noFill()
rect(s * inin - x + d, y-20,((n * k - 1) * u)+2*s ,y+70)
   fill(0)
  //nonio mm
   
  for (inmm = n1; inmm != -1; inmm--) {
    line(s1 * inmm - x1 + d1, y1+200, s1 * inmm - x1 + d1, y1 +280)
    textSize(16);
    text(`${inmm}`, s1 * inmm - x1 - 7 + d1, y1 +300);
  }
   noFill()
rect(s1 * inmm - x1 + d1, y1+200,  ((n1 * k1 - 1) * u1) +2*s1, y1 -70)
   fill(0)
  
  
  
  
  //in
  x = 0
  for (iin = lin; iin != -1; iin--) {
    line(u * iin - x + d, y + 100, u * iin - x + d, y + 200)
  }
  let rel
  if( (lin *u ) > ((lin1*u1)/25.4)){
     rel = (lin*u)+2*u
    }else{
    rel = (((lin1*u1)+2*u1)/25.4)
  }
  
  
    noFill()
rect(u * iin - x + d, y+100 , rel, y+200 )
  r =y+200
  e = rel
  w =y+100
  q =  u* iin - x + d
  
   fill(0)
  /////
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  //mm
  x1 = 0
  for (imm = lin1; imm != -1; imm--) {
    line(u1 * imm - x1 + d1, y1 + 100, u1 * imm - x1 + d1, y1 + 200)
  }
  
   //rots and trans
  
  translate(0, 0);
  rotate(3 * HALF_PI);
  //in
  for (iin = lin; iin != -1; iin--) {
    textSize(18);
    text(`${(iin*(u/es)).toFixed(4)}`, y - 300, u * iin + x +d);
  }
  //mm
  for (imm = lin1; imm != -1; imm--) {
    textSize(14);
    text(`${(imm*(u1/es1)).toFixed(4)}`, y1 - 590, u1 * imm + x1 + d1);
  }


}